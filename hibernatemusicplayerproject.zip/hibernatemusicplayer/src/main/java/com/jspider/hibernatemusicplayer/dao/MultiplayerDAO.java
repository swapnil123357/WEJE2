package com.jspider.hibernatemusicplayer.dao;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.TransactionException;

import com.jspider.hibernatemusicplayer.dto.MultiplayerDTO;

public class MultiplayerDAO {
	static boolean loop = true;
	private static EntityManagerFactory entityManagerFactory;
	private static EntityManager entityManager;
	private static EntityTransaction entityTransaction;
	private static Scanner scanner = new Scanner(System.in);
	private static javax.persistence.Query query;

	public static void main(String[] args) {
		openConnections();
		menu();
		entityTransaction.commit();
		closeConnections();
	}

	private static void menu() {
		System.out.println(
				"Choose to make operation for \n1. Play Song \n2. Add Or Remove Song \n3. Edit Song \n4. Display all song \n5.Exist ");
		int choose = scanner.nextInt();
		switch (choose) {
		case 1:
			playSong();
			break;
		case 2:
			addOrRemoveSongs();
			break;
		case 3:
			editSong();
			break;
		case 4:
			displayAllSong();
			break;
		default:
			exist();
			break;
		}
	}

	private static void playSong() {
		System.out.println("Choose any option \n1. Choose Song \n2. Play All Song\n3. Random Song\n4. Go back");
		int choose = scanner.nextInt();
		switch (choose) {
		case 1:
			chooseSongToPlay();
			break;
		case 2:
			playAllSongs();
			break;
		case 3:
			playRandomeSong();
			break;
		default:
			menu();
			break;
		}
	}

	private static void addOrRemoveSongs() {
		System.out.println("Choose any option \n1. Add Song \n2. Remove Song\n3. Go Back");
		int choose = scanner.nextInt();
		switch (choose) {
		case 1:
			addSong();
			break;
		case 2:
			removeSongs();
			break;
		default:
			menu();
			break;
		}
	}

	private static void editSong() {
		System.out.println("Choose option \n1. Update song ");
		int choose = scanner.nextInt();
		switch (choose) {
		case 1:
			update();
			break;
		default:
			menu();
			break;
		}
	}

	private static void exist() {
		System.out.println("You are exist from application");
	}

	private static void openConnections() {
		entityManagerFactory = Persistence.createEntityManagerFactory("Music");
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
	}

	private static void closeConnections() {
		if (entityManagerFactory != null) {
			entityManagerFactory.close();
		}
		if (entityManager != null) {
			entityManager.close();
		}
		if (entityTransaction != null) {
			try {
				entityTransaction.rollback();
			} catch (TransactionException e) {
				System.out.println("Transaction is already commited");
			}
		}
	}

	private static void chooseSongToPlay() {
		entityTransaction.begin();
		for (int i = 1; i <= 10; i++) {
			System.out.println("\n" + entityManager.find(MultiplayerDTO.class, i) + "\n");
		}
		System.out.println("Enter the Song ID that you want to play");
		int songChoice = scanner.nextInt();
		System.out.println(entityManager.find(MultiplayerDTO.class, songChoice).getSongName() + " is now playing");
		entityTransaction.commit();
	}

	private static void playAllSongs() {
		entityTransaction.begin();
		String jpql = "select songName from Song";
		query = entityManager.createQuery(jpql);
		List songs = query.getResultList();
		for (Object song : songs) {
			System.out.println(song + " is now playing");
		}
		entityTransaction.commit();
	}

	private static void playRandomeSong() {
		int b = (int) Math.random();
		System.out.println(entityManager.find(MultiplayerDTO.class, b).getSongName() + " is now playing...");
	}

	private static void addSong() {
		System.out.println("Please enter the number of songs you want of ADD");
		int noOfSongs = scanner.nextInt();
		entityTransaction.begin();
		for (int i = 0; i < noOfSongs; i++) {
			MultiplayerDTO song = new MultiplayerDTO();
			System.out.println("Enter Song ID");
			song.setId(scanner.nextInt());
			System.out.println("Enter Song Name");
			song.setSongName(scanner.nextLine());
			System.out.println("Enter Singer Name");
			song.setSingerName(scanner.nextLine());
			System.out.println("Enter Movie Name");
			song.setMovieName(scanner.nextLine());
			System.out.println("Enter Composer Name");
			song.setComposer(scanner.nextLine());
			System.out.println("Enter Lyricist");
			song.setLyricist(scanner.nextLine());
			System.out.println("Enter Song Length");
			song.setLength(scanner.nextDouble());
			entityManager.persist(song);
			System.out.println(song.toString());
			System.out.println("");
		}
		entityTransaction.commit();
	}

	private static void removeSongs() {
		entityTransaction.begin();
		System.out.println("Please enter which song you want to delete with only its id= ");
		int take = scanner.nextInt();
		String jpql = "delete from MultiplayerDTO where id=" + take;
		query = entityManager.createQuery(jpql);
		int update2 = query.executeUpdate();
		System.out.println(update2 + "row(s) deleted");
		entityTransaction.commit();
	}

	private static void update() {
		entityTransaction.begin();
		String jpql;
		int update;
		System.out.println(
				"what changes you want to make\n1.song id\n2.song name\n3. singar name\n.4 movie name \n.5 composer \n.6 lyricist \n.7 length");
		int a = scanner.nextInt();
		switch (a) {
		case 1:
			System.out.println("Please enter which song you want to update with only its id= ");
			int take = scanner.nextInt();
			jpql = "update MultiplayerDTO set id=1 where id =" + take;
			query = entityManager.createQuery(jpql);
			update = query.executeUpdate();
			System.out.println(update + "row(s) updated");
			break;

		case 2:
			System.out.println("Please enter which song you want to update with only its song name= ");
			String take1 = scanner.nextLine();
			jpql = "update MultiplayerDTO set songName=songName1 where songName=" + take1;
			query = entityManager.createQuery(jpql);
			update = query.executeUpdate();
			System.out.println(update + "row(s) updated");
			break;

		case 3:
			System.out.println("Please enter which song you want to update with only its Singer name= ");
			String take2 = scanner.nextLine();
			jpql = "update MultiplayerDTO set singerName=singerName1 where singerName=" + take2;
			query = entityManager.createQuery(jpql);
			update = query.executeUpdate();
			System.out.println(update + "row(s) updated");
			break;

		case 4:
			System.out.println("Please enter which song you want to update with only its movie name= ");
			String take3 = scanner.nextLine();
			jpql = "update MultiplayerDTO set movieName=movieName1 where movieName=" + take3;
			query = entityManager.createQuery(jpql);
			update = query.executeUpdate();
			System.out.println(update + "row(s) updated");
			break;

		case 5:
			System.out.println("Please enter which song you want to update with only its composer= ");
			String take4 = scanner.nextLine();
			jpql = "update MultiplayerDTO set composer=composer1 where composer=" + take4;
			query = entityManager.createQuery(jpql);
			update = query.executeUpdate();
			System.out.println(update + "row(s) updated");
			break;

		case 6:
			System.out.println("Please enter which song you want to update with only its lyricist= ");
			String take5 = scanner.nextLine();
			jpql = "update MultiplayerDTO set lyricist=lyricist1 where lyricist=" + take5;
			query = entityManager.createQuery(jpql);
			update = query.executeUpdate();
			System.out.println(update + "row(s) updated");
			break;

		case 7:
			System.out.println("Please enter which song you want to update with only its length= ");
			double take6 = scanner.nextDouble();
			jpql = "update MultiplayerDTO set length=length1 where length=" + take6;
			query = entityManager.createQuery(jpql);
			update = query.executeUpdate();
			System.out.println(update + "row(s) updated");
			break;
		default:
			System.out.println("wrong input" + "please choose correct option");
			update();
		}
		entityTransaction.commit();
	}

	private static void displayAllSong() {
		entityTransaction.begin();
		String jpql = "select songName from MultiplayerDTO";
		query = entityManager.createQuery(jpql);
		List songs = query.getResultList();
		for (Object song : songs) {
			System.out.println(song);
		}
		entityTransaction.commit();
	}
}
