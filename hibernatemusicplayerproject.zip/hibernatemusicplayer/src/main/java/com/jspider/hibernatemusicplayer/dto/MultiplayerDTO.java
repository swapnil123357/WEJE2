package com.jspider.hibernatemusicplayer.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Song")

public class MultiplayerDTO {
	@Id
	int id;
	String songName;
	String singerName;
	String movieName;
	String composer;
	String lyricist;
	double length;

}
